"""
Your module description
"""
print("Hello,World")
a="string"
b=1245
c=12.322
d=True
print(type(a))
print(type(b))
print(type(c))
print(type(d))