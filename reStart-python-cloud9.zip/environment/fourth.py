a=["apple","monkey","orange"]
print(a)
print(type(a))

print(a[1])
a[1]="banana"
print(a)

b=("dog","cat","lion")
print(b)
print(type(b))

print(a[1])
print(b)


c={"1":"nani","2":"mani","3":"jani"}
print(type(c))
print(c)
print(c["3"])
print(c["2"])
print(c["1"])
c["3"]="ani"
print(c)

