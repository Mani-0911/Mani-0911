mystring="hello"
print(mystring)
print(type(mystring))
print(mystring + " is the value of " + str(type(mystring)))

a="hi"
b="all"
c="How are you?"
print(a+" " + b +","+c)
name=input("enter your name:")
color=input("Enter your favourite colour:")
animal=input("Enter your favourite animal:")
print("{} you like a {} colour and {} is your favourite animal".format(name,color,animal))
