print("Python has three numeric types: int, float, and complex")
print(2+2)
print(4-2)
print(9+8)
a=10
b=34
c=5.6
d=5j
e=True
print(a+b);print(a-b);print(a*b);print(a/b);print(a//b);print(a%b)
print(type(a))
print(type(c))
print(type(d))
print(str(a) +"is the data type of"+ str(type(a)))
print(str(c) +"is a data type of"+ str(type(c)))
print(str(d) +"is a data type of"+ str(type(d)))
print(str(e) +"is a data type of"+ str(type(e)))