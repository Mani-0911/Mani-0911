a=(1,2.5,"mani","25",True)
print(a)
print(type(a))
print(a[2])

for item in a:
    print("{} is of the datatype {}".format(item,type(item)) )